/*
 *  @(#)gamma3_hw.h	1.22 19/12/21
 *
 *  gamma3.h: gamma3 support routines
 *
 *  AMB gamma3 high resolution DAC software control and display
 *  gamma3 design by Ti Kan
 *  LCDuino-1 Team: Bryan Levin, Ti Kan
 *
 *  Project websites:
 *	http://www.amb.org/audio/gamma3/
 *	http://www.amb.org/audio/gamma24/
 *	http://www.amb.org/audio/alpha24/
 *	http://www.amb.org/audio/zeta1/
 *	http://www.amb.org/audio/lcduino1/
 *	http://www.amb.org/audio/sigma11/
 *	http://www.amb.org/audio/sigma22/
 *  Discussion forum:
 *	http://www.amb.org/forum/
 *
 *  Author:
 *	Ti Kan (AMB Laboratories)
 *	Copyright (c) 2009-2020 Ti Kan
 *	All rights reserved.
 *
 *  LICENSE
 *  -------
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#ifndef _GAMMA3_HW_H_
#define _GAMMA3_HW_H_

// gamma3 class
class GAMMA3 {
public:
	GAMMA3(void);
	void	init(void);
	void	halt(void);
	void	set_volume(byte vol);
	void	set_input(byte input, byte mode);
	void	set_filter(byte filt);
	void	set_anticlip(byte mode);
	void	set_upsample(byte rate);
	void	set_dit_mode(byte input, byte mode);
	void	set_phase(byte rate);
	void	set_deemphasis(byte mode);
	void	set_uac_mode(byte mode);
	byte	get_sample_rate(void);
private:
	byte	mcp23xx8_read(byte reg);
	void	mcp23xx8_write(byte reg, byte val);
	byte	src4392_read(byte reg);
	void	src4392_write(byte reg, byte val);
	void	wm8741_write(byte idx, byte reg, byte val);
	void	init_mcp23xx8(void);
	void	init_src4392(void);
	void	init_wm8741(void);
	void	reset(void);
	void	unreset(void);
	byte	get_uac_mode(void);
	byte	mcp23xx8_i2c_addr;
	byte	src4392_i2c_addr;
	byte	wm8741_i2c_addr[2];
	byte	mcp_gpio;
	byte	wm8741_reg04;
	byte	muted;
	byte	initted;
};

extern GAMMA3	gamma3;

#endif // _GAMMA3_HW_H_

