/*
 *  @(#)config.h	1.15 19/12/21
 *
 *  config.h: compile-time feature configuration
 *
 *  AMB gamma3 high resolution DAC software control and display
 *  gamma3 design by Ti Kan
 *  LCDuino-1 Team: Bryan Levin, Ti Kan
 *
 *  Project websites:
 *	http://www.amb.org/audio/gamma3/
 *	http://www.amb.org/audio/gamma24/
 *	http://www.amb.org/audio/alpha24/
 *	http://www.amb.org/audio/zeta1/
 *	http://www.amb.org/audio/lcduino1/
 *	http://www.amb.org/audio/sigma11/
 *	http://www.amb.org/audio/sigma22/
 *  Discussion forum:
 *	http://www.amb.org/forum/
 *
 *  Author:
 *	Ti Kan (AMB Laboratories) based on work by Bryan Levin (Sercona Audio)
 *	Copyright (c) 2009-2020 Bryan Levin, Ti Kan
 *	All rights reserved.
 *
 *  LICENSE
 *  -------
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
#ifndef _CONFIG_H_
#define _CONFIG_H_

/*
 * DEBUG switches
 */

//#define DEBUG_IR1		1	// spy on the IR codes being received
//#define DEBUG_SENSED_POT	1	// see the values as you turn the pot
//#define USE_SOFTSERIAL_UART	1	// for debug
//#define USE_SERIAL_UART	1	// for debug
//#define USE_MEM_CHECKER	1	// see free RAM left at runtime
//#define DEBUG_GAMMA3		1	// gamma3 debug

/*
 * FEATURE switches: these enable/disable code (and feature) sections
 */

// This is used to enable the LED13 to blink when an IR code was received
// (feedback to the user)
#define APP_BLINK_ON_LED13	1

// Enable more IR protocols than Sony (NEC, RC5, RC6)
#define NON_SONY		1

// Enable 'big fonts' for some displays
#define USE_BIGFONTS		1
//#define USE_THICKER_BIGFONT	1	// thicker alternate big font

// Use an analog linear potentiometer for volume and other functions
#define USE_ANALOG_POT		1	// linear pot

// The potentiometer is motorized (define USE_ANALOG_POT with this one)
#define USE_MOTOR_POT		1	// motor is via h-bridge driver

// How much time before dimming the display when in auto-dim mode
#define DISPLAY_AUTODIM_TIME	6	// in seconds

// For power control
#define USE_POWER_RELAY		1	// SSR or buffered relay

// Enable this for gamma3 v1.0 prototype boards (not for production boards)
//#define GAMMA3_PROTOTYPE	1

// Enable this if you're using an epsilon31 bridge board between
// the gamma3 backplane board and the LCDuino-1 board.
#define USE_EPSILON31		1

// gamma3 debug requires serial UART
// This should not be modified
// 
#ifdef DEBUG_GAMMA3
#define USE_SERIAL_UART		1
#endif

#endif // _CONFIG_H_

