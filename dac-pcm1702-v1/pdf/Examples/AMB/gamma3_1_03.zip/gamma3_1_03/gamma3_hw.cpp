/*
 *  @(#)gamma3_hw.cpp	1.34 19/12/24
 *
 *  gamma3_hw.cpp: gamma3 hardware interfaces
 *
 *  AMB gamma3 high resolution DAC software control and display
 *  gamma3 design by Ti Kan
 *  LCDuino-1 Team: Bryan Levin, Ti Kan
 *
 *  Project websites:
 *	http://www.amb.org/audio/gamma3/
 *	http://www.amb.org/audio/gamma24/
 *	http://www.amb.org/audio/alpha24/
 *	http://www.amb.org/audio/zeta1/
 *	http://www.amb.org/audio/lcduino1/
 *	http://www.amb.org/audio/sigma11/
 *	http://www.amb.org/audio/sigma22/
 *  Discussion forum:
 *	http://www.amb.org/forum/
 *
 *  Author:
 *	Ti Kan (AMB Laboratories)
 *	Copyright (c) 2009-2020 Ti Kan
 *	All rights reserved.
 *
 *  LICENSE
 *  -------
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#define GAMMA3_HW_CPP
#include "common.h"

// LCDuino-1 dedicated MCU I/O pin numbers for gamma3
// (OC) = open collector
#define Z_LED1		_D2_PIN		// input: UAC1 flag
#define Z_LED2		_D3_PIN		// input: UAC2 flag
#define Z_VBUS_EN	_D4_PIN		// input: zeta1 power-on detect
#define Z_GPIO_09	_D5_PIN		// input: DSD detect
#if defined(GAMMA3_PROTOTYPE) && defined(USE_EPSILON31)
// prototype gamma3 backplane board
#define L_LOCK		_D12_PIN	// input: SRC4392 DIR LOCK flag (OC)
#define L_RDY		_D11_PIN	// input: SRC4392 DIR RDY flag (OC)
#define L_INT		_D10_PIN	// input: SRC4392 interrupt (OC)
#else
// production gamma3 backplane board
#define L_LOCK		_D10_PIN	// input: SRC4392 DIR LOCK flag (OC)
#define L_RDY		_D11_PIN	// input: SRC4392 DIR RDY flag (OC)
#define L_INT		_D12_PIN	// input: SRC4392 interrupt (OC)
#endif

// gamma3 MCP23008: Bitmask of GPIO port input/output
#define MCP_INPUT_MASK	0x0f		// 1 = input, 0 = output

// gamma3 MCP23008: Bitmask of GPIO port names
#define MCP_GPIO_PROG	0x80		// output
#define MCP_GPIO_NRST	0x40		// output
#define MCP_GPIO_PCMDSD	0x20		// output
#define MCP_GPIO_RESET	0x10		// output
#define MCP_GPIO_GP01	0x08		// input
#define MCP_GPIO_GP02	0x04		// input
#define MCP_GPIO_GP03	0x02		// input
#define MCP_GPIO_GP04	0x01		// input

// SRC4392 control/status registers
#define SRC_REG01	0x01		// power down and reset
#define SRC_REG02	0x02		// global interrupt status
#define SRC_REG03	0x03		// port A control
#define SRC_REG04	0x04		// port A control
#define SRC_REG05	0x05		// port B control
#define SRC_REG06	0x06		// port B control
#define SRC_REG07	0x07		// DIT control
#define SRC_REG08	0x08		// DIT control
#define SRC_REG09	0x09		// DIT control
#define SRC_REG0A	0x0a		// SRC and DIT status
#define SRC_REG0B	0x0b		// SRC and DIT interrupt mask
#define SRC_REG0C	0x0c		// SRC and DIT interrupt mode
#define SRC_REG0D	0x0d		// DIR control
#define SRC_REG0E	0x0e		// DIR control
#define SRC_REG0F	0x0f		// DIR PLL configuration
#define SRC_REG10	0x10		// DIR PLL configuration
#define SRC_REG11	0x11		// DIR PLL configuration
#define SRC_REG12	0x12		// non-PCM audio detection
#define SRC_REG13	0x13		// DIR status
#define SRC_REG14	0x14		// DIR status
#define SRC_REG15	0x15		// DIR status
#define SRC_REG16	0x16		// DIR interrupt mask
#define SRC_REG17	0x17		// DIR interrupt mask
#define SRC_REG18	0x18		// DIR interrupt mode
#define SRC_REG19	0x19		// DIR interrupt mode
#define SRC_REG1A	0x1a		// DIR interrupt mode
#define SRC_REG1B	0x1b		// GP01
#define SRC_REG1C	0x1c		// GP02
#define SRC_REG1D	0x1d		// GP03
#define SRC_REG1E	0x1e		// GP04
#define SRC_REG1F	0x1f		// audio CD Q-channel subcode
#define SRC_REG20	0x20		// audio CD Q-channel subcode
#define SRC_REG21	0x21		// audio CD Q-channel subcode
#define SRC_REG22	0x22		// audio CD Q-channel subcode
#define SRC_REG23	0x23		// audio CD Q-channel subcode
#define SRC_REG24	0x24		// audio CD Q-channel subcode
#define SRC_REG25	0x25		// audio CD Q-channel subcode
#define SRC_REG26	0x26		// audio CD Q-channel subcode
#define SRC_REG27	0x27		// audio CD Q-channel subcode
#define SRC_REG28	0x28		// audio CD Q-channel subcode
#define SRC_REG29	0x29		// PC burst preamble, high byte
#define SRC_REG2A	0x2a		// PC burst preamble, low byte
#define SRC_REG2B	0x2b		// PD burst preamble, high byte
#define SRC_REG2C	0x2c		// PD burst preamble, low byte
#define SRC_REG2D	0x2d		// SRC control
#define SRC_REG2E	0x2e		// SRC control
#define SRC_REG2F	0x2f		// SRC control
#define SRC_REG30	0x30		// SRC control
#define SRC_REG31	0x31		// SRC control
#define SRC_REG32	0x32		// SRC input/output ratio
#define SRC_REG33	0x33		// SRC input/output ratio
#define SRC_REG7F	0x7f		// page selection

// WM8741 control registers
// The register number is the datasheet listed number << 1
#define WM_REG00	0x00		// volume adjustment L LSB
#define WM_REG01	0x02		// volume adjustment L MSB
#define WM_REG02	0x04		// volume adjustment R LSB
#define WM_REG03	0x06		// volume adjustment R MSB
#define WM_REG04	0x08		// volume control
#define WM_REG05	0x0a		// format control
#define WM_REG06	0x0c		// filter control
#define WM_REG07	0x0e		// mode control 1
#define WM_REG08	0x10		// mode control 2
#define WM_REG09	0x12		// software reset
#define WM_REG32	0x40		// additional controls


// Instantiation of the gamma3 class
GAMMA3	gamma3 = GAMMA3();


// Ctor
GAMMA3::GAMMA3(void)
{
	// I2C addresses (these are fixed in hardware)
	mcp23xx8_i2c_addr = 0x20;
	src4392_i2c_addr = 0x70;	
	wm8741_i2c_addr[0] = 0x1a;	// differential mono L
	wm8741_i2c_addr[1] = 0x1b;	// differential mono R

	// cached MCP23008 GPIO mask
	mcp_gpio = 0;

	// cached WM8741 register 4 content
	wm8741_reg04 = 0;

	// flag to indicate that soft-mute is in effect
	muted = 0;

	// initialized flag
	initted = 0;
}


// Read one byte from the MCP23008
byte
GAMMA3::mcp23xx8_read(byte reg)
{
	byte	val;
#ifdef DEBUG_GAMMA3
	byte	status;
#endif

	if (!initted)
		return 0;

#ifdef DEBUG_GAMMA3
	status =
#endif
	i2c_read(mcp23xx8_i2c_addr, reg, &val);

#ifdef DEBUG_GAMMA3
	Serial.print("mcp23xx8_read: i2c_read(");
	Serial.print(reg, HEX);
	Serial.print(") = ");
	Serial.println(status, HEX);
#endif

	return val;
}


// Write one byte to the MCP23008
void
GAMMA3::mcp23xx8_write(byte reg, byte val)
{
#ifdef DEBUG_GAMMA3
	byte	status;
#endif

	if (!initted)
		return;

#ifdef DEBUG_GAMMA3
	status =
#endif
	i2c_write(mcp23xx8_i2c_addr, reg, val);

#ifdef DEBUG_GAMMA3
	Serial.print("mcp23xx8_write: i2c_write(");
	Serial.print(reg, HEX);
	Serial.print(",");
	Serial.print(val, HEX);
	Serial.print(") = ");
	Serial.println(status, HEX);
#endif
}


// Read one byte from the SRC4392
byte
GAMMA3::src4392_read(byte reg)
{
	byte	val;
#ifdef DEBUG_GAMMA3
	byte	status;
#endif

	if (!initted)
		return 0;

#ifdef DEBUG_GAMMA3
	status =
#endif
	i2c_read(src4392_i2c_addr, reg, &val);

#ifdef DEBUG_GAMMA3
	Serial.print("src4392_read: i2c_read(");
	Serial.print(reg, HEX);
	Serial.print(") = ");
	Serial.println(status, HEX);
#endif

	return val;
}


// Write one byte to the SRC4392
void
GAMMA3::src4392_write(byte reg, byte val)
{
#ifdef DEBUG_GAMMA3
	byte	status;
#endif

	if (!initted)
		return;

#ifdef DEBUG_GAMMA3
	status =
#endif
	i2c_write(src4392_i2c_addr, reg, val);

#ifdef DEBUG_GAMMA3
	Serial.print("src4392_write: i2c_write(");
	Serial.print(reg, HEX);
	Serial.print(",");
	Serial.print(val, HEX);
	Serial.print(") = ");
	Serial.println(status, HEX);
#endif
}


// Write one byte to the specified WM8741
// idx: 0 = first, 1 = second
void
GAMMA3::wm8741_write(byte idx, byte reg, byte val)
{
#ifdef DEBUG_GAMMA3
	byte	status;
#endif

	if (!initted)
		return;

#ifdef DEBUG_GAMMA3
	status =
#endif
	i2c_write(wm8741_i2c_addr[idx], reg, val);

#ifdef DEBUG_GAMMA3
	Serial.print("wm8741_write: i2c_write(");
	Serial.print(reg, HEX);
	Serial.print(",");
	Serial.print(val, HEX);
	Serial.print(") = ");
	Serial.println(status, HEX);
#endif
}


// Initialize the MCP23008
void
GAMMA3::init_mcp23xx8(void)
{
	// Set up the MCP23008 on the gamma3
	mcp23xx8_write(MCP_REG_IOCON, 0x0c);
	delay(50);
	mcp23xx8_write(MCP_REG_IODIR, MCP_INPUT_MASK);
	delay(50);
	mcp23xx8_write(MCP_REG_GPPU, MCP_INPUT_MASK);
	delay(50);
}


// Initialize the SRC4392
void
GAMMA3::init_src4392(void)
{
	// Select page 0
	src4392_write(SRC_REG7F, 0x00);

	// DIR setup:
	// - set default input source
	// - use MCLK as clock source
	// - audio not muted for loss of lock condition
	// - PLL stops for loss of lock condition
	// - RXCKO output disabled
	src4392_write(SRC_REG0D, 0x08);	// default input source = RX1
	src4392_write(SRC_REG0E, 0x00);

	// PLL1 setup:
	// 24.576MHz, p = 2, j = 8, d = 0
	src4392_write(SRC_REG0F, 0x22);
	src4392_write(SRC_REG10, 0x00);
	src4392_write(SRC_REG11, 0x00);

	// Set GP01 for DIR non-audio flag
	src4392_write(SRC_REG1B, 0x06);
	// Set GP02 for DIR non-valid flag
	src4392_write(SRC_REG1C, 0x07);
	// Set GP03 for DIR emphasis flag
	src4392_write(SRC_REG1D, 0x05);
	// Set GP04 for DIR parity error flag
	src4392_write(SRC_REG1E, 0x0d);

	// SRC setup:
	// - DIR as the input data source
	// - use MCLK as clock source
	// - autodem enabled
	src4392_write(SRC_REG2D, 0x02);	// default input source = DIR
	src4392_write(SRC_REG2E, 0x20);
	src4392_write(SRC_REG2F, 0x00);
	src4392_write(SRC_REG30, 0x00);
	src4392_write(SRC_REG31, 0x00);

	// DIT setup:
	// - SRC as the input data source
	// - MCLK as master clock
	// - clock divider 128 to set the output frame rate
	// - block start is an output and valid audio is indicated
	// - c and u data will not be updated
	src4392_write(SRC_REG07, 0x1c);
	src4392_write(SRC_REG08, 0x00);
	src4392_write(SRC_REG09, 0x00);

	// set up for 192KHz output
	src4392_write(SRC_REG08, 0x08);
	src4392_write(SRC_REG7F, 0x02);
	src4392_write(0x00, 0x80);
	src4392_write(0x01, 0x80);
	src4392_write(0x08, 0x18);
	src4392_write(0x09, 0x18);
	src4392_write(SRC_REG7F, 0x00);
	src4392_write(SRC_REG08, 0x00);

	// Power up all blocks
	src4392_write(SRC_REG01, 0x3f);

	// Port A setup:
	// - master with i2s data format
	// - SRC as input data source
	// - MCLK as clock source
	// - clock divider 128
	src4392_write(SRC_REG03, 0x39);
	src4392_write(SRC_REG04, 0x00);

	// Port B setup:
	// - slave with i2s data format
	src4392_write(SRC_REG05, 0x01);
	src4392_write(SRC_REG06, 0x00);
}


// Initialize the WM8741(s)
void
GAMMA3::init_wm8741(void)
{
	unsigned int	vol;
	byte		reg0, reg1;

	// pre-set WM8741 register 4 initial content:
	// - enable volume ramp mode
	// - anti-clip disabled
	// - right volume follows left volume
	// - soft-mute disabled
	// - zflag disabled
	wm8741_reg04 = 0x65;
	muted = 0;

	// Reset the WM8741s
	wm8741_write(0, WM_REG09, 0x00);
	wm8741_write(1, WM_REG09, 0x00);
	delay(100);

	// Mute audio
	wm8741_reg04 |= 0x08;
	wm8741_write(0, WM_REG04, wm8741_reg04);
	wm8741_write(1, WM_REG04, wm8741_reg04);

	// Set default volume = minimum
	vol = 0x3ff;
	reg0 = (byte) (vol & 0x1f);
	reg1 = (byte) (vol >> 5) | 0x20;
	wm8741_write(0, WM_REG00, reg0);
	wm8741_write(0, WM_REG01, reg1);
	wm8741_write(0, WM_REG02, reg0);
	wm8741_write(0, WM_REG03, reg1);
	wm8741_write(1, WM_REG00, reg0);
	wm8741_write(1, WM_REG01, reg1);
	wm8741_write(1, WM_REG02, reg0);
	wm8741_write(1, WM_REG03, reg1);

#ifdef GAMMA3_PROTOTYPE
	// Set format:
	// - 24 bits
	// - I2S format
	// - LRCLK polarity inversion
	// - powered up
	wm8741_write(0, WM_REG05, 0x1a);
	wm8741_write(1, WM_REG05, 0x1a);
#else
	// Set format:
	// - 24 bits
	// - I2S format
	// - no polarity inversion
	// - powered up
	wm8741_write(0, WM_REG05, 0x0a);
	wm8741_write(1, WM_REG05, 0x0a);
#endif

	// Set mode:
	// - PCM mode
	// - auto-detect sample rate
	// - OSR high rate (192KHz)
	// - not 8FS mode
	wm8741_write(0, WM_REG07, 0x40);
	wm8741_write(1, WM_REG07, 0x40);

#ifdef GAMMA3_PROTOTYPE
	// Set mode:
	// - dither off
	// - diff-mono right, left
	// - no daisy-chain
	// - high DSD output level (2Vrms)
	wm8741_write(0, WM_REG08, 0x4c);
	wm8741_write(1, WM_REG08, 0x44);
#else
	// Set mode:
	// - dither off
	// - diff-mono left, right
	// - no daisy-chain
	// - high DSD output level (2Vrms)
	wm8741_write(0, WM_REG08, 0x44);
	wm8741_write(1, WM_REG08, 0x4c);
#endif

	// Un-mute audio
	wm8741_reg04 &= 0xf7;
	wm8741_write(0, WM_REG04, wm8741_reg04);
	wm8741_write(1, WM_REG04, wm8741_reg04);
}


// Reset the gamma3
void
GAMMA3::reset(void)
{
	// Reset the gamma3
	mcp_gpio &= ~MCP_GPIO_RESET;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
}


// Un-reset the gamma3
void
GAMMA3::unreset(void)
{
	// Un-reset the gamma3
	// this turns on the local voltage regulators
	mcp_gpio |= MCP_GPIO_RESET;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
	delay(1000);
}


// Return the current UAC mode
byte
GAMMA3::get_uac_mode(void)
{
	byte	led1 = 0, led2 = 0;

	if (digitalRead(Z_VBUS_EN) == 0)
		// zeta1 not installed or not powered up
		return USB_MODE_INVAL;

	led1 = digitalRead(Z_LED1);
	led2 = digitalRead(Z_LED2);

	if (led1 && !led2)
		return USB_MODE_UAC1;
	else if (!led1 && led2)
		return USB_MODE_UAC2;
	else
		return USB_MODE_INVAL;
}


// Initialize the gamma3
void
GAMMA3::init(void)
{
	initted = 1;

	// Set mode of MCU I/O pins
	pinMode(Z_LED1, INPUT);
	pinMode(Z_LED2, INPUT);
	pinMode(Z_VBUS_EN, INPUT);
	pinMode(Z_GPIO_09, INPUT);
	pinMode(L_LOCK, INPUT);
	pinMode(L_RDY, INPUT);
	pinMode(L_INT, INPUT);

	// Wait for the gamma24 5V power to stabilize
	delay(100);

	// Initialize the MCP23008 on the gamma3 main board
	init_mcp23xx8();

	// Un-reset the gamma3
	// This has the effect of enabling the voltage regulators
	unreset();

	// Initialize the SRC4392 on the gamma24 module
	init_src4392();

	// Initializa the WM8741s on the gamma24 module
	init_wm8741();
}


// Halt the gamma3
void
GAMMA3::halt(void)
{
	if (!initted)
		return;

	// Mute audio
	set_volume(0);

	initted = 0;

	// The main parts of gamma3 are about to power off, do nothing more.
}


// Set the WM8741 volume
// vol: 0..255
void
GAMMA3::set_volume(byte vol)
{
	unsigned int	val;
	byte		reg0, reg1;

	if (vol == 0) {
		// special case for minimum volume: do a soft mute instead
		muted = 1;

		wm8741_reg04 |= 0x08;
		wm8741_write(0, WM_REG04, wm8741_reg04);
		wm8741_write(1, WM_REG04, wm8741_reg04);

		return;
	}

	// un-mute
	if (muted) {
		muted = 0;

		wm8741_reg04 &= 0xf7;
		wm8741_write(0, WM_REG04, wm8741_reg04);
		wm8741_write(1, WM_REG04, wm8741_reg04);
	}

	// translate 0..0xff to 0x3ff..0
	val = (~vol) << 2;
	reg0 = (byte) (val & 0x1f);
	reg1 = (byte) (val >> 5) | 0x20;

	// Write to the left channel volume control registers of both DACs
	// The right channel is configured to follow the left in
	// init_wm8741().
	wm8741_write(0, WM_REG00, reg0);
	wm8741_write(0, WM_REG01, reg1);
	wm8741_write(1, WM_REG00, reg0);
	wm8741_write(1, WM_REG01, reg1);
}


// Set the input
// input: 0..4, mode: DIT_UPSAMPLE or DIT_LOOPOUT
void
GAMMA3::set_input(byte input, byte mode)
{
	byte	val;

	if ((input >= MAX_INPUTS) ||
	    (mode != DIT_UPSAMPLE && mode != DIT_LOOPOUT))
		return;		// error checking

	// Select page 0
	src4392_write(SRC_REG7F, 0x00);

	if (input == 0) {
		// Special case for USB
		// set SRC input source to port B
		src4392_write(SRC_REG2D, 0x01);
	}
	else {
		// - set DIR input source to the appropriate RX port
		// - use MCLK as clock source
		// - audio muted for loss of lock condition
		// - PLL free runs for loss of lock condition
		// - RXCKO output disabled
		val = 0x08 | (input - 1);
		src4392_write(SRC_REG0D, val);
		src4392_write(SRC_REG0E, 0x18);

		// set SRC input source to DIR
		src4392_write(SRC_REG2D, 0x02);
	}

	// update DIT mode
	set_dit_mode(input, mode);
}


// Set the WM8741 filter
// filt: FILTER_RESP_1..FILTER_RESP_5
void
GAMMA3::set_filter(byte filt)
{
	byte	val;

	if (filt >= MAX_FILTERS)
		return;		// error checking

	if (filt >= FILTER_RESP_5) {
		val = FILTER_RESP_4;	// DSD mode only has four filters
	}
	else {
		val = filt;
	}
	val = (val << 3) | filt;

	// Set filter response for both PCM and DSD modes
	// - deemphasis mode off
	// - zflag off
	wm8741_write(0, WM_REG06, val);
	wm8741_write(1, WM_REG06, val);
}


// Toggle the WM8741 anti-clip mode
// mode: ANTICLIP_OFF or ANTICLIP_ON
void
GAMMA3::set_anticlip(byte mode)
{
	if (mode != ANTICLIP_OFF && mode != ANTICLIP_ON)
		return;		// error checking

	if (mode == ANTICLIP_OFF) {
		wm8741_reg04 &= 0xfd;
	}
	else if (mode == ANTICLIP_ON) {
		wm8741_reg04 |= 0x02;
	}

	wm8741_write(0, WM_REG04, wm8741_reg04);
	wm8741_write(1, WM_REG04, wm8741_reg04);
}


// Set the upsample rate
// rate: UPSAMPLE_192KHZ or UPSAMPLE_96KHZ
void
GAMMA3::set_upsample(byte rate)
{
	if (rate != UPSAMPLE_192KHZ && rate != UPSAMPLE_96KHZ)
		return;		// error checking

	// Mute audio
	wm8741_reg04 |= 0x08;
	wm8741_write(0, WM_REG04, wm8741_reg04);
	wm8741_write(1, WM_REG04, wm8741_reg04);

	// Select SRC4392 page 0
	src4392_write(SRC_REG7F, 0x00);

	if (rate == UPSAMPLE_192KHZ) {
		// SRC4392 DIT setup:
		// - SRC as the input data source
		// - MCLK as master clock
		// - clock divider 128 to set the output frame rate
		// - block start is an output and valid audio is indicated
		// - c and u data will not be updated
		src4392_write(SRC_REG07, 0x1c);

		// set up for 192KHz output 
		src4392_write(SRC_REG08, 0x08);
		src4392_write(SRC_REG7F, 0x02);
		src4392_write(0x00, 0x80);
		src4392_write(0x01, 0x80);
		src4392_write(0x08, 0x18);
		src4392_write(0x09, 0x18);
		src4392_write(SRC_REG7F, 0x00);
		src4392_write(SRC_REG08, 0x00);

		// SRC4392 Port A setup:
		// - MCLK as clock source
		// - clock divider 128
		src4392_write(SRC_REG04, 0x00);

		// Set WM8741 mode:
		// - PCM mode
		// - auto-detect sample rate
		// - OSR high rate (192KHz)
		// - not 8FS mode
		wm8741_write(0, WM_REG07, 0x40);
		wm8741_write(1, WM_REG07, 0x40);
	}
	else if (rate == UPSAMPLE_96KHZ) {
		// SRC4392 DIT setup:
		// - SRC as the input data source
		// - MCLK as master clock
		// - clock divider 256 to set the output frame rate
		// - block start is an output and valid audio is indicated
		// - c and u data will not be updated
		src4392_write(SRC_REG07, 0x3c);

		// set up for 96KHz output 
		src4392_write(SRC_REG08, 0x08);
		src4392_write(SRC_REG7F, 0x02);
		src4392_write(0x00, 0x80);
		src4392_write(0x01, 0x80);
		src4392_write(0x08, 0x08);
		src4392_write(0x09, 0x08);
		src4392_write(SRC_REG7F, 0x00);
		src4392_write(SRC_REG08, 0x00);

		// SRC4392 Port A setup:
		// - MCLK as clock source
		// - clock divider 256
		src4392_write(SRC_REG04, 0x01);

		// Set WM8741 mode:
		// - PCM mode
		// - auto-detect sample rate
		// - OSR medium rate (96KHz)
		// - not 8FS mode
		wm8741_write(0, WM_REG07, 0x20);
		wm8741_write(1, WM_REG07, 0x20);
	}

	// Un-mute audio
	wm8741_reg04 &= 0xf7;
	wm8741_write(0, WM_REG04, wm8741_reg04);
	wm8741_write(1, WM_REG04, wm8741_reg04);
}


// Set the DIT (digital output) routing
// input: input number, mode: DIT_LOOPOUT or DIT_UPSAMPLE
void
GAMMA3::set_dit_mode(byte input, byte mode)
{
	byte	val;

	if ((mode != DIT_UPSAMPLE && mode != DIT_LOOPOUT) ||
	    input >= MAX_INPUTS)
		return;		// error checking

	// Select SRC4392 page 0
	src4392_write(SRC_REG7F, 0x00);

	if (mode == DIT_UPSAMPLE || input == 0) {
		// For USB we will always set the output for up-sampling
		// because we have no way to set the DIT master clock
		// appropriately when its source is directly from Port B.

		if (upsample_rate == UPSAMPLE_192KHZ) {
			// DIT setup
			// - SRC as the input data source
			// - MCLK as master clock
			// - clock divider 128 to set the output frame rate
			// - block start is an output and valid audio
			//   is indicated
			// - c and u data will not be updated
			src4392_write(SRC_REG07, 0x1c);

			// set up for 192KHz output 
			src4392_write(SRC_REG08, 0x08);
			src4392_write(SRC_REG7F, 0x02);
			src4392_write(0x00, 0x80);
			src4392_write(0x01, 0x80);
			src4392_write(0x08, 0x18);
			src4392_write(0x09, 0x18);
			src4392_write(SRC_REG7F, 0x00);
			src4392_write(SRC_REG08, 0x00);
		}
		else if (upsample_rate == UPSAMPLE_96KHZ) {
			// DIT setup
			// - SRC as the input data source
			// - MCLK as master clock
			// - clock divider 256 to set the output frame rate
			// - block start is an output and valid audio
			//   is indicated
			// - c and u data will not be updated
			src4392_write(SRC_REG07, 0x3c);

			// set up for 96KHz output 
			src4392_write(SRC_REG08, 0x08);
			src4392_write(SRC_REG7F, 0x02);
			src4392_write(0x00, 0x80);
			src4392_write(0x01, 0x80);
			src4392_write(0x08, 0x08);
			src4392_write(0x09, 0x08);
			src4392_write(SRC_REG7F, 0x00);
			src4392_write(SRC_REG08, 0x00);
		}
	}
	else if (mode == DIT_LOOPOUT) {
		// handle regular input 1..4

		// set both AES and TX outputs to receive their
		// data via the bypass multiplexor without going
		// through the DIT block.
		val = ((input - 1)) << 6 | 0x30;
		src4392_write(SRC_REG08, val);
	}
}


// Set the analog output absolute phase
// mode: PHASE_NORMAL or PHASE_INVERT
void
GAMMA3::set_phase(byte mode)
{
#ifdef GAMMA3_PROTOTYPE
	if (mode == PHASE_NORMAL)
#else
	if (mode == PHASE_INVERT)
#endif
	{
		// Set format:
		// - 24 bits
		// - I2S format
		// - LRCLK polarity inversion
		// - powered up
		wm8741_write(0, WM_REG05, 0x1a);
		wm8741_write(1, WM_REG05, 0x1a);

		// Set mode:
		// - dither off
		// - diff-mono right, left
		// - no daisy-chain
		// - high DSD output level (2Vrms)
		wm8741_write(0, WM_REG08, 0x4c);
		wm8741_write(1, WM_REG08, 0x44);
	}
#ifdef GAMMA3_PROTOTYPE
	else if (mode == PHASE_INVERT)
#else
	else if (mode == PHASE_NORMAL)
#endif
	{
		// Set format:
		// - 24 bits
		// - I2S format
		// - no polarity inversion
		// - powered up
		wm8741_write(0, WM_REG05, 0x0a);
		wm8741_write(1, WM_REG05, 0x0a);

		// Set mode:
		// - dither off
		// - diff-mono left, right
		// - no daisy-chain
		// - high DSD output level (2Vrms)
		wm8741_write(0, WM_REG08, 0x44);
		wm8741_write(1, WM_REG08, 0x4c);
	}
}


// Set the digital de-emphasis mode
// mode: DEEMPH_AUTO or DEEMPH_OFF
void
GAMMA3::set_deemphasis(byte mode)
{
	if (mode != DEEMPH_AUTO && mode != DEEMPH_OFF)
		return;		// error checking

	// Select SRC4392 page 0
	src4392_write(SRC_REG7F, 0x00);

	if (mode == DEEMPH_AUTO) {
		src4392_write(SRC_REG2E, 0x20);
	}
	else if (mode == DEEMPH_OFF) {
		src4392_write(SRC_REG2E, 0x00);
	}
}


// Set the UAC mode
// mode: USB_MODE_UAC1 or USB_MODE_UAC2
void
GAMMA3::set_uac_mode(byte mode)
{
	byte	cur_mode;

	cur_mode = get_uac_mode();
	if (cur_mode == mode || cur_mode == USB_MODE_INVAL)
		// already in the correct mode (nothing to do), or
		// zeta1 not installed or not powered up.
		return;

	// Toggle the UAC mode

	// "press" the zeta1 PROG button for 4 seconds
	mcp_gpio |= MCP_GPIO_PROG;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
	delay(4000);
	// "release" the zeta1 PROG button
	mcp_gpio &= ~MCP_GPIO_PROG;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
	delay(100);

	// "press" the zeta1 NRST button
	mcp_gpio |= MCP_GPIO_NRST;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
	delay(100);
	// "release" the zeta1 NRST button
	mcp_gpio &= ~MCP_GPIO_NRST;
	mcp23xx8_write(MCP_REG_OLAT, mcp_gpio);
	delay(500);
}


// Return the enum representing the current sample rate (SAMPLERATE_xxKHZ).
byte
GAMMA3::get_sample_rate(void)
{
	byte	val0, val1;

	// Select SRC4392 page 0
	src4392_write(SRC_REG7F, 0x00);

	val0 = src4392_read(SRC_REG32);
	val1 = src4392_read(SRC_REG33);

	if (upsample_rate == UPSAMPLE_192KHZ) {
		// for output sample rate = 192K
		if ((val0 == 0x07 && val1 == 0xff) ||
		    (val0 == 0x08 && val1 == 0x00)) {
			return SAMPLERATE_192KHZ;
		}
		else if (val0 == 0x07 && val1 == 0x59) {
			return SAMPLERATE_176KHZ;
		}
		else if (val0 == 0x05 && val1 == 0x55) {
			return SAMPLERATE_128KHZ;
		}
		else if ((val0 == 0x03 && val1 == 0xff) ||
			 (val0 == 0x04 && val1 == 0x00)) {
			return SAMPLERATE_96KHZ;
		}
		else if (val0 == 0x03 && val1 == 0xac) {
			return SAMPLERATE_88KHZ;
		}
		else if (val0 == 0x02 && val1 == 0xaa) {
			return SAMPLERATE_64KHZ;
		}
		else if ((val0 == 0x01 && val1 == 0xff) ||
			 (val0 == 0x02 && val1 == 0x00)) {
			return SAMPLERATE_48KHZ;
		}
		else if (val0 == 0x01 && val1 == 0xd6) {
			return SAMPLERATE_44KHZ;
		}
		else if (val0 == 0x01 && val1 == 0x55) {
			return SAMPLERATE_32KHZ;
		}
	}
	else if (upsample_rate == UPSAMPLE_96KHZ) {
		// for output sample rate of 96KHz
		if ((val0 == 0x0f && val1 == 0xff) ||
		    (val0 == 0x10 && val1 == 0x00)) {
			return SAMPLERATE_192KHZ;
		}
		else if (val0 == 0x0e && val1 == 0xb3) {
			return SAMPLERATE_176KHZ;
		}
		else if (val0 == 0x0a && val1 == 0xaa) {
			return SAMPLERATE_128KHZ;
		}
		else if ((val0 == 0x07 && val1 == 0xff) ||
			 (val0 == 0x08 && val1 == 0x00)) {
			return SAMPLERATE_96KHZ;
		}
		else if (val0 == 0x07 && val1 == 0x59) {
			return SAMPLERATE_88KHZ;
		}
		else if (val0 == 0x05 && val1 == 0x55) {
			return SAMPLERATE_64KHZ;
		}
		else if ((val0 == 0x03 && val1 == 0xff) ||
			 (val0 == 0x04 && val1 == 0x00)) {
			return SAMPLERATE_48KHZ;
		}
		else if (val0 == 0x03 && val1 == 0xac) {
			return SAMPLERATE_44KHZ;
		}
		else if (val0 == 0x02 && val1 == 0xaa) {
			return SAMPLERATE_32KHZ;
		}
	}

	return SAMPLERATE_UNKNOWN;
}


