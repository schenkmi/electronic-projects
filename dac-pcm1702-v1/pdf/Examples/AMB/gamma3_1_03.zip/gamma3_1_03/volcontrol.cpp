/*
 *  @(#)volcontrol.cpp	1.21 19/12/24
 *
 *  volcontrol.cpp: volume control functions
 *
 *  AMB gamma3 high resolution DAC software control and display
 *  gamma3 design by Ti Kan
 *  LCDuino-1 Team: Bryan Levin, Ti Kan
 *
 *  Project websites:
 *	http://www.amb.org/audio/gamma3/
 *	http://www.amb.org/audio/gamma24/
 *	http://www.amb.org/audio/alpha24/
 *	http://www.amb.org/audio/zeta1/
 *	http://www.amb.org/audio/lcduino1/
 *	http://www.amb.org/audio/sigma11/
 *	http://www.amb.org/audio/sigma22/
 *  Discussion forum:
 *	http://www.amb.org/forum/
 *
 *  Author:
 *	Ti Kan (AMB Laboratories) based on work by Bryan Levin (Sercona Audio)
 *	Copyright (c) 2009-2020 Bryan Levin, Ti Kan
 *	All rights reserved.
 *
 *  LICENSE
 *  -------
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "common.h"

#ifdef USE_ANALOG_POT
// smooth the reading
int
read_analog_pot_with_smoothing(byte analog_port_num, byte reread_count)
{
	int	sensed_port_value = 0;

	for (byte i = 0; i < reread_count; i++) {
		sensed_port_value += analogRead(analog_port_num);
		// delayMicroseconds(200);
	}

	if (reread_count > 1) {
		sensed_port_value /= reread_count;
	}

	return sensed_port_value;
}


// read the pot, translate its native range to our (min..max) range
// and clip to keep any stray values in that range.
int
read_pot_volume_value_with_clipping(int sensed_pot_value)
{
	int	temp_volume;

	temp_volume = l_map(sensed_pot_value,
			0, // ANALOG_POT_MIN_RANGE,
			ANALOG_POT_MAX_RANGE,
			min_vol, max_vol);

	return temp_volume;
}


void
handle_analog_pot_value_changes(void)
{
	byte	old_vol;
	byte	temp_volume;
	int	sensed_pot_value;

	sensed_pot_value = read_analog_pot_with_smoothing(
		SENSED_ANALOG_POT_INPUT_PIN, POT_REREADS
	);	// to smooth it out

	if (abs(sensed_pot_value - last_seen_pot_value) > POT_CHANGE_THRESH) {
		// 1-5 is a good value to ignore noise

#ifdef DEBUG_SENSED_POT
		/*
		sprintf(buf, "CHANGE! old=[%d] new=[%d]\n",
			last_seen_pot_value, sensed_pot_value);
		Serial.print(buf);
		*/
#endif

		/*
		 * get the pot raw value into our correct volume min..max range
		 */
		old_vol = volume;	// the setting *just* before the
					// user touched the pot
		temp_volume = read_pot_volume_value_with_clipping(
			sensed_pot_value
		);

		if (vol_fine_incr == VOL_FINE_HALF_DB) {
			if (temp_volume == old_vol) {
				// don't update the display (or anything) if
				// there was no *effective* change
				return;
			}
		}
		else if (vol_fine_incr == VOL_FINE_WHOLE_DB) {
			if (abs(temp_volume - old_vol) < 2) {
				// don't update the display (or anything) if
				// there was no *effective* change
				return;
			}
		}

		/*
		 * if we are at this point, there was a real change and
		 * the vol engine needs to be triggered.  we also should
		 * restore backlight just as if the user had pressed a
		 * vol-change IR key.
		 */
		lcd.restore_backlight();

		volume = temp_volume;
		if (temp_volume > old_vol) {
			// are we in mute-mode right now?  if going from mute
			// to 'arrow-up' we should do a slow ramp-up first
			if (mute == 1) {
				// tell the system we are officially
				// out of mute mode, now
				mute = 0;
				update_volume(volume, 1);
			}
			else {
				// not in mute mode, handle the volume
				// increase normally.
				// this also sets the volume but also the
				// graph and db display
				update_volume(temp_volume, 0);
			}
		}
		else {
			// not a volume increase but a decrease
			// this also sets the volume but also the graph
			// and db display
			update_volume(temp_volume, 0);
		}

		/*
		 * since this registered a real change, we save the
		 * timestamp and value in our state variables
		 */
		last_seen_IR_vol_value = volume;
		last_seen_pot_value = sensed_pot_value;
	}
}


// logic on this routine is simple: the only time the pot is allowed
// to be read is when we consider the motor to be stopped (or 'settled').
void
analog_sensed_pot_logic(void)
{
	if (power == POWER_ON) {
		// does this system HAVE an analog motorized pot installed?
		if (option_pot_installed == 1) {
			// admin status is 0 for 'no motor in action, now'.
			// only read the pot IF it's not in motion 'by us'
			if (pot_state == MOTOR_SETTLED ||
			    pot_state == MOTOR_INIT) {
				handle_analog_pot_value_changes();
			}
		} // motor option was installed
	} // power was not off
}
#endif // USE_ANALOG_POT


// sample call: vol_change_relative(VC_UP, VC_FAST);
void
vol_change_relative(byte dir_flag, byte speed_flag)
{
	byte	vol_rate = 0;

	/*
	 * some quick exit tests
	 */

	if (power == POWER_OFF)
		return;	// power was in the 'off' or 'standby' state

	if (dir_flag == VC_UP) {
		if (volume >= max_vol)
			// user asked us to raise volume beyond our max.
			return;
	}
	else if (dir_flag == VC_DOWN) {
		if (volume <= min_vol)
			// user asked us to lower volume beyond our min.
			return;
	}

	if (vol_fine_incr == VOL_FINE_HALF_DB)
		vol_rate = NATIVE_VOL_RATE;
	else if (vol_fine_incr == VOL_FINE_WHOLE_DB)
		vol_rate = NATIVE_VOL_RATE + 1;

	// ok, we have to actually do something.
	lcd.restore_backlight();

	// are we in mute-mode right now?  if going from mute to 'arrow-up'
	// (or 'arrow-right'),
	// we should auto-exit from mute and also let the volume
	// increment take affect.
	if (mute == 1 && dir_flag == VC_UP) {
		mute = 0;
		redraw_volume_display(volume, 1);
	}

	/*
	 * call the vol-control engine
	 */
	if (dir_flag == VC_UP) {
		if (speed_flag == VC_SLOW) {
			// up-slow
			if (volume < max_vol &&
			   (volume + vol_rate) < max_vol) {
				volume += vol_rate;
			}
			else {
				volume = max_vol;
			}

			update_volume(volume, 0);  // 0='relative mode'
		}
		else if (speed_flag == VC_FAST) {
			// up-fast
			if (volume < (max_vol - vol_coarse_incr)) {
				volume += vol_coarse_incr;
			}
			else {
				volume = max_vol;
			}

			update_volume(volume, 0);  // 0='relative mode'
		}
	}
	else if (dir_flag == VC_DOWN) {
		if (speed_flag == VC_SLOW) {
			// down-slow
			if (volume > min_vol &&
			   (volume - vol_rate) > min_vol) {
				volume -= vol_rate;
			}
			else {
				volume = min_vol;
			}

			update_volume(volume, 0);  // 0='relative mode'
		}
		else if (speed_flag == VC_FAST) {
			// down-fast
			if (volume > (min_vol + vol_coarse_incr)) {
				volume -= vol_coarse_incr;
			}
			else {
				volume = min_vol;
			}

			update_volume(volume, 0);  // 0='relative mode'
		}
	}
}


void
format_volume_to_string_buf(byte volume, char *ascii_vol_buf)
{
	int	display_val;
	byte	half_db_flag;
	byte	sign_flag;	// '+' or '-' or ' '

	sign_flag = '-';	// assume it's 'minus', by default

	// this gives us a true negative number for atten's
	display_val = ((int) volume - (int) max_byte_size);

	if (display_val == 0) {
		// remove any + or - signs if the vol is exactly zero
		sign_flag = ' ';
	}

	// now remove the sign from the raw number since we manually manage
	// the sign on our own
	display_val = abs(display_val);

	// print based on our db-stepsize

	if (vol_fine_incr == VOL_FINE_HALF_DB) {
		if (display_val & 0x01) {
			// on odd numbers, set the
			// 'we need a .5dB printout' flag
			half_db_flag = '5';
		}
		else {
			// even numbers, we print a .0dB instead
			half_db_flag = '0';
		}

		display_val /= 2;

#ifdef USE_BIGFONTS
		if (big_mode == 1 && toplevel_mode == TOPLEVEL_MODE_NORMAL) {
			sprintf(ascii_vol_buf, "%3d%c",
				display_val, half_db_flag);
		}
		else
#endif
		{
			sprintf(ascii_vol_buf, "%c%3d.%c",
				sign_flag, display_val, half_db_flag);
		}
	}
	else if (vol_fine_incr == VOL_FINE_WHOLE_DB) {
		const char	*pad;

		pad = (toplevel_mode == TOPLEVEL_MODE_NORMAL) ? "" : "  ";

		display_val /= 2;

		if (display_val == 0)
			sprintf(ascii_vol_buf, " %s%3d", pad, display_val);
		else
			sprintf(ascii_vol_buf, "%s%c%3d",
				pad, sign_flag, display_val);
	}

	strcat(ascii_vol_buf, "dB");
}


void
send_vol_byte_to_engines(byte vol_byte, byte forced_admin_flag)
{
	if (mute == 1)
		return;	// global mute disables any vol-changes

	if (vol_byte != last_volume || forced_admin_flag) {
		// Make the volume change in hardware
		gamma3.set_volume(vol_byte);

		// here is where we capture our last-used value
		last_volume = vol_byte;
	}

	/*
	 * we don't always spend cycles writing the value to EEPROM,
	 * but we save a timestamp of the last time we wrote a new value
	 * and if it's 'too old' at some point, the eeprom writer task
	 * (routine) will flush it to eeprom.
	 */
	EEwrite_cached_vol_value_write(vol_byte);
}


void
redraw_volume_display(byte vol_byte, byte forced_admin_flag)
{
#ifdef USE_BIGFONTS
	if (big_mode == 1)
		redraw_volume_display_bigfonts(vol_byte);
	else
#endif
		redraw_volume_display_smallfonts(vol_byte, forced_admin_flag);
}


void
redraw_volume_display_smallfonts(byte vol_byte, byte forced_admin_flag)
{
	int	x_val;

	/*
	 * always display dB numbers in the right/bottom area
	 */
	format_volume_to_string_buf(vol_byte, string_buf);
	lcd.command(LCD_CURS_POS_L2_HOME + lcd_phys_rows - strlen(string_buf));
	lcd.send_string(string_buf, 0); // display formated volume string

	// if we have to do a redraw, always clear out the lower/left area
	if (forced_admin_flag == 1) {
		/*
		 * bottom/left: draw either: MUTE or bargraph
		 */
		if (mute == 1) {
			lcd_clear_8_chars(LCD_MAIN_MUTE_LOC);
			lcd.send_string_P(fl_st_MUTE, LCD_MAIN_MUTE_LOC);
		}
	}

	if (display_mode == EEPROM_DISP_MODE_BARGRAPH && mute != 1) {
		if (vol_span == 0) {
			x_val = (int) (vol_byte * 100) / (int) 0xff;
		}
		else {
			x_val = abs(vol_byte - min_vol);
			x_val = (int) (x_val * 100) / (int) vol_span;
		}

		lcd.draw_graphic_bar(
			string_buf,
			x_val,
			// max size of graph, in char-cells
			char_cell_graph_size
		);

		// print bargraph to lcd
		lcd.send_string(string_buf, LCD_CURS_POS_L2_HOME);
	}
}


#ifdef USE_BIGFONTS
void
redraw_volume_display_bigfonts(byte vol_byte)
{
	format_volume_to_string_buf(vol_byte, string_buf);

	// display volume as BIG numerals
	lcd.draw_big_numeral_db_chars(string_buf);
}
#endif	// USE_BIGFONTS


/*
 * send the volume to all hardware
 * also update the bottom half of the lcd display (graph, db value, etc)
 */
void
update_volume(byte vol_byte, byte forced_admin_flag)
{
	/*
	 * this really sends a vol-change to all our engines
	 */
	send_vol_byte_to_engines(vol_byte, forced_admin_flag);

	// redraw the bottom line of the screen
	redraw_volume_display(volume, forced_admin_flag);
}


#ifdef USE_MOTOR_POT
void
motor_pid(void)
{
	int	target_pot_wiper_value;
	int	admin_sensed_pot_value;

	// given the 'IR' set volume level, find out what wiper value
	// we should be comparing with
	target_pot_wiper_value = l_map(volume, min_vol, max_vol,
					ANALOG_POT_MIN_RANGE,
					ANALOG_POT_MAX_RANGE);

	// this is the oper value of the pot, from the a/d converter
	admin_sensed_pot_value = read_analog_pot_with_smoothing(
		SENSED_ANALOG_POT_INPUT_PIN, POT_REREADS
	);

	if (abs(target_pot_wiper_value - admin_sensed_pot_value) <= 8) {
		// stop the motor!
		digitalWrite(MOTOR_POT_ROTATE_CCW, LOW);  // stop turning left
		digitalWrite(MOTOR_POT_ROTATE_CW,  LOW);  // stop turning right
		pot_state = MOTOR_COASTING;
		delay(5);  // 5ms
		return;
	}
	else {
		/*
		 * not at target volume yet
		 */

		if (admin_sensed_pot_value < target_pot_wiper_value) {
			// turn clockwise

			// stop turning left
			digitalWrite(MOTOR_POT_ROTATE_CCW, LOW);
			// start turning right
			digitalWrite(MOTOR_POT_ROTATE_CW,  HIGH);
		}
		else if (admin_sensed_pot_value > target_pot_wiper_value) {
			// turn counter-clockwise

			// stop turning right
			digitalWrite(MOTOR_POT_ROTATE_CW,  LOW);
			// start turning left
			digitalWrite(MOTOR_POT_ROTATE_CCW, HIGH);
		}
	}
}


// a state-driven dispatcher
void
motor_pot_logic(void)
{
	int		admin_sensed_pot_value = 0;
	static int	motor_stabilized;

	/*
	 * simple PID control for motor pot
	 */

	if (power == POWER_OFF)
		return;

	// If max_vol == min_vol then don't run the motor
	if (vol_span == 0)
		return;

#if 0
	if (mute == 1)
		return;	// don't spin the motor if the user
			// just went down to MUTE
#endif

	switch (pot_state) {
	case MOTOR_INIT:
		/*
		 * initial state, just go to 'settled' from here
		 */
		pot_state = MOTOR_SETTLED;
		last_seen_IR_vol_value = volume;
		break;

	case MOTOR_SETTLED:
		/*
		 * if we are 'settled' and the pot wiper changed,
		 * it was via a human.  this doesn't affect our
		 * motor-driven logic.
		 */
		// if the volume changed via the user's IR, this should
		// trigger us to move to the next state
		if (volume != last_seen_IR_vol_value) {
			pot_state = MOTOR_IN_MOTION;
			last_seen_pot_value = read_analog_pot_with_smoothing(
				SENSED_ANALOG_POT_INPUT_PIN, POT_REREADS
			);
		}

		last_seen_IR_vol_value = volume;
		break;

	case MOTOR_IN_MOTION:
		/*
		 * if the motor is moving, we are looking for our target
		 * so we can let go of the motor and let it 'coast' to a stop
		 */
		lcd.restore_backlight();

		motor_stabilized = 0;
		motor_pid();
		break;

	case MOTOR_COASTING:
		/*
		 * we are waiting for the motor to stop
		 * (which means the last value == this value)
		 */
		lcd.restore_backlight();
		delay(20);
		admin_sensed_pot_value = read_analog_pot_with_smoothing(
			SENSED_ANALOG_POT_INPUT_PIN, POT_REREADS
		);
		if (admin_sensed_pot_value == last_seen_pot_value) {
			if (++motor_stabilized >= 5) {
				// yay! we reached our target
				pot_state = MOTOR_SETTLED;
			}
		}
		else {
			// we found a value that didn't match,
			// so reset our 'sameness' counter
			motor_stabilized = 0;
		}

		// this is the operating value of the pot,
		// from the a/d converter
		last_seen_pot_value = admin_sensed_pot_value;
		break;

	default:
		break;
	}
}
#endif // USE_MOTOR_POT


void
change_input_selector(byte new_in_sel)
{
	// forced admin; write to eeprom to save current value to 'old' portnum
	cache_flush_save_current_vol_level(1);

	// copy to RAM (globals)
	input_selector = new_in_sel;
	EEPROM.write(EEPROM_INPUT_SEL, input_selector);

	/*
	 * restore last-used volume setting based on this input selector switch
	 * note: if in 'global mute' mode, don't touch any volume setting
	 * in the engine!
	 */

	if (mute != 1) {
		send_vol_byte_to_engines(0, 0);	// volume mute
		delay(2);
	}

	volume = EEPROM.read(EEPROM_INPUT_VOL_BASE + input_selector);

	if (volume > max_vol)
		volume = max_vol;
	if (volume < min_vol)
		volume = min_vol;

	if (mute != 1) {
		// volume restore (based on the new input port)
		send_vol_byte_to_engines(volume, 1);
	}

	// forced admin; write to eeprom even if the cache 'suggests'
	// it's too early
	cache_flush_save_current_vol_level(1);

	// switch the input in hardware
	gamma3.set_input(input_selector, dit_mode);
}


void
EEwrite_cached_vol_value_write(byte volume)
{
	// invalidate the cache since our new value is not the same
	// as the one in EEPROM, now
	eewrite_cur_vol_dirtybit = 1;
	eewrite_cur_vol_ts = millis();	// mark the time of our
					// last value_change event
	eewrite_cur_vol_value = volume;
}


void
cache_flush_save_current_vol_level(byte admin_forced_write_flag)
{
	// if the user does NOT force a flush, follow normal checking procedure
	if (admin_forced_write_flag == 0) {
		// if our value is not in sync with what's in EEPROM
		if (eewrite_cur_vol_dirtybit != 1) {
			return;
		}

		// extra check: only save vol level if it's been longer
		// than X amount of time since last EEPROM vol level write
		if (abs(millis() - eewrite_cur_vol_ts) <=
			EEPROM_VOL_FLUSH_INTERVAL) {
			return;
		}
	}
	else {
		eewrite_cur_vol_value = volume; // capture the value, right now
	}

	EEPROM.write(EEPROM_INPUT_SEL, input_selector);
	EEPROM.write(EEPROM_INPUT_VOL_BASE + input_selector,
		     eewrite_cur_vol_value);
	eewrite_cur_vol_dirtybit = 0;	// clear the dirtybit flag
	eewrite_cur_vol_ts = 0;		// reset our timestamp
}


