/*
 *  @(#)common.h	1.17 19/12/24
 *
 *  common.h: common definitions, global functions and variables
 *
 *  AMB gamma3 high resolution DAC software control and display
 *  gamma3 design by Ti Kan
 *  LCDuino-1 Team: Bryan Levin, Ti Kan
 *
 *  Project websites:
 *	http://www.amb.org/audio/gamma3/
 *	http://www.amb.org/audio/gamma24/
 *	http://www.amb.org/audio/alpha24/
 *	http://www.amb.org/audio/zeta1/
 *	http://www.amb.org/audio/lcduino1/
 *	http://www.amb.org/audio/sigma11/
 *	http://www.amb.org/audio/sigma22/
 *  Discussion forum:
 *	http://www.amb.org/forum/
 *
 *  Author:
 *	Ti Kan (AMB Laboratories) based on work by Bryan Levin (Sercona Audio)
 *	Copyright (c) 2009-2020 Bryan Levin, Ti Kan
 *	All rights reserved.
 *
 *  LICENSE
 *  -------
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _COMMON_H_
#define _COMMON_H_

#include <ctype.h>
#include <inttypes.h>
#include <string.h>
#include <math.h>

#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include <util/delay.h>
#include <util/atomic.h>

// gamma3 firmware version number
#ifndef PROG_VER
#define PROG_VER		"1.03"  // must be 4-characters long
#endif

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#include "WConstants.h"
#endif

#ifndef GAMMA3_HW_CPP
#include "Wire.h"
#include "EEPROM.h"
#endif

#ifdef USE_SOFTSERIAL_UART
#include "SoftwareSerial.h"
#endif

#include "config.h"
#include "lcd1_libs.h"
#include "volcontrol.h"
#include "gamma3_hw.h"

/*
 * Size and type of display (currently only 16x2 LCD is supported)
 */
#define DISPLAY_SIZE_16_2	0
#define DISPLAY_SIZE_20_2	1
#define DISPLAY_SIZE_40_2	2
#define DISPLAY_SIZE_20_4	3

#define DISPLAY_TYPE_LCD	0
#define DISPLAY_TYPE_VFD	1

#define DEFAULT_DISPLAY_SIZE	DISPLAY_SIZE_16_2
#define DEFAULT_DISPLAY_TYPE	DISPLAY_TYPE_LCD

/*
 * Arduino pins (offical for LCDuino-1 for gamma3)
 */

#define _A0_PIN				0	// unused
#define SENSED_ANALOG_POT_INPUT_PIN	1	// unused
#define _D2_PIN				2	// for gamma3 _D2
#define _D3_PIN				3	// for gamma3 _D3
#define _D4_PIN				4	// for gamma3 _D4
#define _D5_PIN				5	// for gamma3 _D5
#define _D6_PIN				6	// for gamma3 _D6
#define RELAY_POWER_PIN			7	// power SSR 5V relay trigger
#define IR_PIN				8	// IR Sensor data-out pin to us
#define PWM_BACKLIGHT_PIN		9	// pwm-controlled LED backlight
#define _D10_PIN			10	// for gamma3 _D10
#define _D11_PIN			11	// for gamma3 _D11
#define _D12_PIN			12	// for gamma3 _D12
#define LED13				13	// Arduino standard
#define MOTOR_POT_ROTATE_CW		16	// motor pot control
#define MOTOR_POT_ROTATE_CCW		17	// motor pot control

/*
 * extern/global vars (mostly things defined in the main .ino file)
 */

extern const char	fl_st_MUTE[];	// PROGMEM = "Mute";

extern byte		power;
extern byte		toplevel_mode;	// 0=main mode, all others sub-modes
extern byte		mute;
extern byte		volume;

extern byte		upsample_rate;
extern byte		dit_mode;

extern signed char	input_selector;
extern signed char	old_input;	// for input change events

extern byte		min_vol;
extern byte		max_vol;
extern byte		vol_span;
extern byte		max_byte_size;
extern byte		vol_fine_incr;
extern byte		vol_coarse_incr;

extern unsigned long	eewrite_cur_vol_ts;
extern byte		eewrite_cur_vol_dirtybit;
extern byte		eewrite_cur_vol_value;

extern byte		option_pot_installed;
extern byte		option_motor_pot_installed;

extern int		last_seen_pot_value;	// range from 0..1023
extern byte		last_seen_IR_vol_value;
extern byte		last_volume; 
extern byte		pot_state;

extern byte		display_mode;
extern byte		big_mode;

/*
 * globally visible functions
 */

extern void		common_startup(byte admin_forced_flag);

extern void		draw_selector_string(void);
extern void		draw_sample_rate_display(byte admin_flag);
extern void		change_input_selector(byte new_in_sel);

extern byte		reverse_bit_order(byte flag);

extern void		motor_pot_logic(void);
extern void		analog_sensed_pot_logic(void);
extern void		handle_analog_pot_value_changes(void);
extern int		read_pot_volume_value_with_clipping(
				int sensed_pot_value);
extern int		read_analog_pot_with_smoothing(
				byte analog_port_num, byte reread_count);

extern void		redraw_volume_display(
				byte vol_byte, byte forced_admin_flag);
extern void		redraw_volume_display_smallfonts(
				byte vol_byte, byte forced_admin_flag);
extern void		redraw_volume_display_bigfonts(byte vol_byte);

extern void		cache_flush_save_current_vol_level(
				byte forced_admin_flag);
extern void		update_volume(byte volume, byte admin_forced_flag);
extern void		vol_change_relative(byte dir_flag, byte speed_flag);

extern void		send_vol_byte_to_engines(
				byte vol_byte, byte forced_admin_flag);

extern void		draw_graphic_bar(char *dest_buf, int value,
				int total_bargraph_size);
extern void		format_volume_to_string_buf(
				byte volume, char *ascii_vol_buf);
extern void		pad_string_buf_with_spaces(byte count);

extern void		recache_data_index_and_type(void);

#endif // _COMMON_H_

